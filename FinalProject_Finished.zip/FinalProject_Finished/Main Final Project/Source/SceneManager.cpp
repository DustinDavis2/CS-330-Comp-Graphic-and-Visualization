///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		
		if (m_textureIDs[i].ID)
		{
			glDeleteTextures(1, &m_textureIDs[i].ID);
			m_textureIDs[i].ID = 0;
		}
		m_loadedTextures = 0;
	}
}

// what was here
//{
//	glGenTextures(1, &m_textureIDs[i].ID);
//}

/***********************************************************
*   InitShadowResources()
*
*   Creates a depth only texture + FBO used as a shadow map.
*   Called once in PrepareScene().
************************************************************/
void SceneManager::InitShadowResources()
{
	if (m_shadowFBO != 0 && m_shadowTex != 0)
		return;

	glGenFramebuffers(1, &m_shadowFBO);
	glBindFramebuffer(GL_FRAMEBUFFER, m_shadowFBO);

	glGenTextures(1, &m_shadowTex);
	glBindTexture(GL_TEXTURE_2D, m_shadowTex);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, m_shadowSize, 
		m_shadowSize, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
	float border[4] = { 1.f, 1.f, 1.f, 1.f };
	glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, border);

	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, m_shadowTex, 0);

	// depth only pass: no color targets
	glDrawBuffer(GL_NONE);
	glReadBuffer(GL_NONE);

	if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
		std::cout << "Shadow FBO incomplete!" << std::endl;

	glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

/**********************************************************
*  UpdateLightSpaceAndBindShadow()
*  
*  Builds the light space matrix from Light 0 each frame and 
*  binds the depth texture so the shader can sample it.
*  Called at the start of RenderScene().
************************************************************/
void SceneManager::UpdateLightSpaceAndBindShadow()
{
	// must match your SetupSceneLights() values for Light 0
	glm::vec3 L0pos = glm::vec3(0.0f, 35.0f, 6.0f);
	glm::vec3 target0 = glm::vec3(0.0f, 7.0f, -3.0f);
	glm::vec3 L0dir = glm::normalize(target0 - L0pos);

	// simple perspective frustum that covers your stage
	glm::mat4 lightProj = glm::perspective(glm::radians(45.0f), 1.0f, 0.5f, 200.0f);
	glm::mat4 lightView = glm::lookAt(L0pos, target0, glm::vec3(0.0f, 1.0f, 0.0f));

	m_lightSpaceMatrix = lightProj * lightView;
	m_pShaderManager->setMat4Value("lightSpaceMatrix", m_lightSpaceMatrix);

	// bind the shadow map for sampling on unit 15
	glActiveTexture(GL_TEXTURE0 + 15);
	glBindTexture(GL_TEXTURE_2D, m_shadowTex);
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);

		glm::mat3 normalMatrix = glm::transpose(glm::inverse(glm::mat3(modelView)));
		m_pShaderManager->setMat3Value("normalMatrix", normalMatrix);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************
*  SetScratchTexture()
*
*  This method is used for adding blended texture for 
*  wear and tear to meshes.
***************************************************************/
void SceneManager::SetScratchTextures(
	std::string scratch1Tag,
    std::string scratch2Tag,
	std::string scratch3Tag)
{
	int slot1 = this->FindTextureSlot(scratch1Tag);
	int slot2 = this->FindTextureSlot(scratch2Tag);
	int slot3 = this->FindTextureSlot(scratch3Tag);

	if (slot1 >= 0) m_pShaderManager->setSampler2DValue("scratch1", slot1);
	if (slot2 >= 0) m_pShaderManager->setSampler2DValue("scratch2", slot2);
	if (slot3 >= 0) m_pShaderManager->setSampler2DValue("scratch3", slot3);
}

/**************************************************************
*  SetScratchUVScale()
*
*  Set UV tiling scale for scratch overlay.
***************************************************************/
void SceneManager::SetScratchUVScale(float u, float v)
{
	m_pShaderManager->setVec2Value("scratchUVscale", glm::vec2(u, v));
}

/**************************************************************
*  SetUseScratch()
*
*  This method is used to turn on or off scratch tedture
***************************************************************/
void SceneManager::SetUseScratch(bool useScratch)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue("bUseScratch", useScratch);
	}
}

/***********************************************************
 *  SetupSceneLights()
 *  Adds two spotlights
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// enable custom lighting in the shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// --- Light 0: warm ceiling key (overhead, slightly front), aimed at bench area ---
	glm::vec3 L0pos = glm::vec3(0.0f, 35.0f, 6.0f);
	glm::vec3 target0 = glm::vec3(0.0f, 7.0f, -3.0f);
	glm::vec3 L0dir = glm::normalize(target0 - L0pos);

	m_pShaderManager->setVec3Value("lightSources[0].position", L0pos.x, L0pos.y, L0pos.z);
	m_pShaderManager->setVec3Value("lightSources[0].direction", L0dir.x, L0dir.y, L0dir.z);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.20f, 0.20f, 0.20f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 1.50f, 1.50f, 1.60f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.50f, 1.50f, 1.50f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 40.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.30f);
	m_pShaderManager->setFloatValue("lightSources[0].cutOff", glm::cos(glm::radians(19.0f)));
	m_pShaderManager->setFloatValue("lightSources[0].outerCutOff", glm::cos(glm::radians(24.0f)));

	// --- Light 1: cool fill (wide and gentle) ---
	glm::vec3 L1pos = glm::vec3(-28.0f, 8.0f, 20.0f);
	glm::vec3 target1 = glm::vec3(0.0f, 3.0f, 0.0f);
	glm::vec3 L1dir = glm::normalize(target1 - L1pos);

	m_pShaderManager->setVec3Value("lightSources[1].position", L1pos.x, L1pos.y, L1pos.z);
	m_pShaderManager->setVec3Value("lightSources[1].direction", L1dir.x, L1dir.y, L1dir.z);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.05f, 0.07f, 0.10f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.10f, 0.15f, 0.40f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.10f, 0.15f, 0.40f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.10f);
	m_pShaderManager->setFloatValue("lightSources[1].cutOff", glm::cos(glm::radians(88.0f)));
	m_pShaderManager->setFloatValue("lightSources[1].outerCutOff", glm::cos(glm::radians(89.0f)));

	// view position for specular math; update per-frame if you have a moving camera
	m_pShaderManager->setVec3Value("viewPosition", 0.0f, 5.0f, 10.0f);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadPyramid3Mesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTaperedBoxMesh();

	// avoid 4-byte row padding surprises when loading textures
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	// added load texture files into OpenGL and bind it for later use
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/PianoWood.jpg", "pianoWood");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/LightWoodFloor.jpg", "lightWoodFloor");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/Scratches01.png", "scratch1");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/Scratches02.png", "scratch2");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/Scratches03.png", "scratch3");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/WallPaint.jpg", "wallPaint");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/BlackMetal.jpg", "blackMetal");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/PosterImage.jpg", "posterImage");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/gold-seamless-texture.jpg", "gold");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/stainless.jpg", "stainless");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/FrostedGlass.jpg", "frostedGlass");
	CreateGLTexture("C:/Users/Dustin/OneDrive/Desktop/School stuff/CS 330 - Comp Graphic & Visualization/FinalProject/Utilities/textures/PianoPoster.jpg", "pianoPoster");
	BindGLTextures();  // Binds all loaded textures

	// adds two-light setup
	SetupSceneLights();

	// create shadow map resources and tell the shader which unit touse
	InitShadowResources();
	m_pShaderManager->setSampler2DValue("shadowMap", 15);

	// Set default material so lighting has sane values
	m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(0.28f, 0.30f, 0.36f));
	m_pShaderManager->setFloatValue("material.ambientStrength", 0.42f);
	m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(0.75f));
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 40.0f);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	m_pShaderManager->setIntValue("bUseLighting", true);

	m_pShaderManager->setVec3Value("viewPosition", 0.0f, 5.0f, 10.0f);

	UpdateLightSpaceAndBindShadow();

	/******************************************************************
	*  Shadow depth pass (Light 0)
	*  Renders scene into the depth only FBO to build shadow map.
	*******************************************************************/
	{
		// bind shadow FBO and set viewport to shadow map size
		glBindFramebuffer(GL_FRAMEBUFFER, m_shadowFBO);
		glViewport(0, 0, m_shadowSize, m_shadowSize);
		glClear(GL_DEPTH_BUFFER_BIT);

		glEnable(GL_DEPTH_TEST);

		glDisable(GL_CULL_FACE);
		glEnable(GL_POLYGON_OFFSET_FILL);
		glPolygonOffset(1.0f, 1.5f);

		// switch vertex shader path to light space
		m_pShaderManager->setBoolValue("bShadowPass", true);
		m_pShaderManager->setIntValue("bUseLighting", false);
		m_pShaderManager->setIntValue("bUseTexture", false);

		// === BEGIN: GEOMETRY FOR SHADOW DEPTH PASS =================================
		{
			// local transform scratch
			glm::vec3 scaleXYZ;
			float XrotationDegrees, YrotationDegrees, ZrotationDegrees;
			glm::vec3 positionXYZ;

			/****************************************************************
			 * FLOOR
			 ****************************************************************/
			scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, -4.05f, 0.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawPlaneMesh();

			/****************************************************************
			 * PIANO BENCH � SEAT TOP
			 ****************************************************************/
			scaleXYZ = glm::vec3(10.3f, 0.5f, 5.3f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, 3.3f, 0.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
			 * PIANO BENCH � SEAT BASE
			 ****************************************************************/
			scaleXYZ = glm::vec3(10.0f, 1.5f, 5.0f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, 2.7f, 0.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
			 * PIANO BENCH � LEGS (FRONT LEFT / FRONT RIGHT / BACK LEFT / BACK RIGHT)
			 ****************************************************************/
			 // Front Left
			scaleXYZ = glm::vec3(0.5f, 6.0f, 0.5f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(-4.5f, -1.05f, 2.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawTaperedBoxMesh();

			// Front Right
			positionXYZ = glm::vec3(4.5f, -1.05f, 2.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawTaperedBoxMesh();

			// Back Left
			positionXYZ = glm::vec3(-4.5f, -1.05f, -2.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawTaperedBoxMesh();

			// Back Right
			positionXYZ = glm::vec3(4.5f, -1.05f, -2.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawTaperedBoxMesh();

			/****************************************************************
			 * BACK WALL
			 ****************************************************************/
			scaleXYZ = glm::vec3(20.0f, 1.0f, 15.0f);
			XrotationDegrees = 90.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, 10.94f, -10.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawPlaneMesh();

			/****************************************************************
			 * UPRIGHT PIANO � MAIN CABINET
			 ****************************************************************/
			scaleXYZ = glm::vec3(30.0f, 17.5f, 5.5f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, 1.2f, -7.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
			 * UPRIGHT PIANO � TOP SHELF OVERHANG
			 ****************************************************************/
			scaleXYZ = glm::vec3(30.8f, 0.6f, 6.2f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, 10.0f, -6.8f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
			 * UPRIGHT PIANO � KEYBED / FRONT LEDGE
			 ****************************************************************/
			scaleXYZ = glm::vec3(30.0f, 1.6f, 4.0f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, 6.0f, -2.3f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
			 * UPRIGHT PIANO � FRONT LEFT LEG
			 ****************************************************************/
			scaleXYZ = glm::vec3(1.0f, 10.0f, 1.0f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(-14.5f, 1.0f, -1.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawTaperedBoxMesh();

			/****************************************************************
			 * UPRIGHT PIANO � FRONT RIGHT LEG
			 ****************************************************************/
			positionXYZ = glm::vec3(14.5f, 1.0f, -1.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawTaperedBoxMesh();

			/****************************************************************
			 * UPRIGHT PIANO � PEDAL BOX
			 ****************************************************************/
			scaleXYZ = glm::vec3(4.0f, 1.2f, 1.0f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, -2.8f, -3.8f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
			 * UPRIGHT PIANO � THREE PEDALS (L / M / R)
			 ****************************************************************/
			scaleXYZ = glm::vec3(0.25f, 0.25f, 1.2f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			glm::vec3 pedalBase = glm::vec3(0.0f, -3.0f, -3.4f);

			// Left
			positionXYZ = pedalBase + glm::vec3(-1.2f, 0.0f, 0.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawTaperedCylinderMesh();
			// Middle
			positionXYZ = pedalBase + glm::vec3(0.0f, 0.0f, 0.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawTaperedCylinderMesh();
			// Right
			positionXYZ = pedalBase + glm::vec3(1.2f, 0.0f, 0.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawTaperedCylinderMesh();

			/****************************************************************
			 * UPRIGHT PIANO � MUSIC STAND
			 ****************************************************************/
			scaleXYZ = glm::vec3(14.0f, 3.8f, 0.4f);
			XrotationDegrees = -12.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, 10.0f, -3.4f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
			 * UPRIGHT PIANO � FALLBOARD (KEY COVER)
			 ****************************************************************/
			scaleXYZ = glm::vec3(29.0f, 4.0f, 0.6f);
			XrotationDegrees = -80.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, 7.5f, -2.20f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
			 * UPRIGHT PIANO � FALLBOARD REST
			 ****************************************************************/
			scaleXYZ = glm::vec3(29.0f, 2.6f, 0.4f);
			XrotationDegrees = -90.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(0.0f, 8.06f, -3.5f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
			 * UPRIGHT PIANO � SIDE BARRIERS (RIGHT then LEFT)
			 ****************************************************************/
			 // Right (x = +14.74)
			scaleXYZ = glm::vec3(4.0f, 2.0f, 0.4f);
			XrotationDegrees = 0.0f; YrotationDegrees = 90.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(14.74f, 7.6f, -2.34f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			// Left (x = -14.74)
			positionXYZ = glm::vec3(-14.74f, 7.6f, -2.34f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			/****************************************************************
            *  LAMP � depth pass  (match visible transforms exactly)
            ****************************************************************/
			glm::vec3 lampBasePos = glm::vec3(9.5f, 10.3f, -6.6f);

			// base
			scaleXYZ = glm::vec3(1.20f, 0.40f, 1.20f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = lampBasePos;
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawCylinderMesh();

			// base ring
			scaleXYZ = glm::vec3(1.25f, 0.06f, 1.25f);
			positionXYZ = lampBasePos + glm::vec3(0.0f, 0.01f, 0.0f);
			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
			m_basicMeshes->DrawCylinderMesh();

			// collar
			scaleXYZ = glm::vec3(0.20f, 0.26f, 0.20f);
			positionXYZ = lampBasePos + glm::vec3(0.0f, 0.30f, 0.0f);
			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
			m_basicMeshes->DrawCylinderMesh();

			// gooseneck segments (same as visible)
			scaleXYZ = glm::vec3(0.10f, 0.90f, 0.10f);
			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, lampBasePos + glm::vec3(0.000f, 0.50f, 0.00f)); m_basicMeshes->DrawCylinderMesh();

			scaleXYZ = glm::vec3(0.10f, 0.60f, 0.10f);
			SetTransformations(scaleXYZ, 12.0f, 0.0f, 4.0f, lampBasePos + glm::vec3(0.000f, 1.30f, 0.00f)); m_basicMeshes->DrawCylinderMesh();

			scaleXYZ = glm::vec3(0.10f, 0.60f, 0.10f);
			SetTransformations(scaleXYZ, 14.0f, 0.0f, 4.5f, lampBasePos + glm::vec3(-0.042f, 1.85f, 0.10f)); m_basicMeshes->DrawCylinderMesh();

			scaleXYZ = glm::vec3(0.10f, 0.60f, 0.10f);
			SetTransformations(scaleXYZ, 18.0f, 0.0f, 5.0f, lampBasePos + glm::vec3(-0.080f, 2.40f, 0.24f)); m_basicMeshes->DrawCylinderMesh();

			scaleXYZ = glm::vec3(0.10f, 0.80f, 0.10f);
			SetTransformations(scaleXYZ, 20.0f, 0.0f, 5.0f, lampBasePos + glm::vec3(-0.140f, 2.90f, 0.40f)); m_basicMeshes->DrawCylinderMesh();

			// head mount
			scaleXYZ = glm::vec3(0.22f, 0.16f, 0.22f);
			SetTransformations(scaleXYZ, 45.0f, 0.0f, 5.0f, lampBasePos + glm::vec3(-0.18f, 3.55f, 0.58f));
			m_basicMeshes->DrawCylinderMesh();

			// shade (cone)
			scaleXYZ = glm::vec3(0.95f, 1.95f, 0.95f);
			SetTransformations(scaleXYZ, -55.0f, -12.0f, -15.0f, lampBasePos + glm::vec3(-0.50f, 3.40f, 1.45f));
			m_basicMeshes->DrawConeMesh();

			// shade rim
			scaleXYZ = glm::vec3(0.80f, 0.05f, 0.80f);
			SetTransformations(scaleXYZ, -55.0f, -12.0f, -15.0f, lampBasePos + glm::vec3(-0.50f, 3.38f, 1.48f));
			m_basicMeshes->DrawCylinderMesh();

			// socket + bulb
			scaleXYZ = glm::vec3(0.22f, 0.12f, 0.22f);
			SetTransformations(scaleXYZ, -55.0f, -12.0f, 0.0f, lampBasePos + glm::vec3(-0.45f, 3.30f, 1.14f));
			m_basicMeshes->DrawCylinderMesh();

			scaleXYZ = glm::vec3(0.18f, 0.18f, 0.18f);
			SetTransformations(scaleXYZ, -55.0f, -12.0f, 0.0f, lampBasePos + glm::vec3(-0.45f, 3.30f, 1.20f));
			m_basicMeshes->DrawSphereMesh();

			/****************************************************************
            *  WALL PICTURE � depth pass (match visible)
            ****************************************************************/
            // Poster panel
			scaleXYZ = glm::vec3(1.5f, 1.5f, 3.0f);
			XrotationDegrees = 90.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(-4.0f, 17.5f, -9.98f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawPlaneMesh();

			// Frame � top rail
			scaleXYZ = glm::vec3(3.2f, 0.4f, 0.2f);
			XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
			positionXYZ = glm::vec3(-4.0f, 20.70f, -9.95f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			// Frame � bottom rail
			scaleXYZ = glm::vec3(3.2f, 0.4f, 0.2f);
			positionXYZ = glm::vec3(-4.0f, 14.30f, -9.95f);
			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			// Frame � left rail
			scaleXYZ = glm::vec3(0.3f, 6.8f, 0.2f);
			positionXYZ = glm::vec3(-5.65f, 17.5f, -9.95f);
			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			// Frame � right rail
			positionXYZ = glm::vec3(-2.38f, 17.5f, -9.95f);
			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
			m_basicMeshes->DrawBoxMesh();
		}
		// === END: GEOMETRY FOR SHADOW DEPTH PASS ===================================

		// restore 
		glDisable(GL_POLYGON_OFFSET_FILL);
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
		m_pShaderManager->setBoolValue("bShadowPass", false);
		m_pShaderManager->setIntValue("bUseLighting", true);

		BindGLTextures();
		glActiveTexture(GL_TEXTURE0 + 15);
		glBindTexture(GL_TEXTURE_2D, m_shadowTex);

		glViewport(0, 0, 1280, 720);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	}

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, -4.05f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// rough floor material
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.15f));
	m_pShaderManager->setFloatValue("material.shininess", 10.0f);

	// apply light wood floor texture
	SetShaderTexture("lightWoodFloor");
	SetTextureUVScale(2.0f, 1.0f);
	SetUseScratch(false);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	// restore material for other objects
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.5f));
	m_pShaderManager->setFloatValue("material.shininess", 24.0f);
	/****************************************************************/

	/*****************************************************************
    *                     DEBUG LIGHT MARKERS                       *
    ******************************************************************/

    // Light 0 marker (white spotlight source)
	scaleXYZ = glm::vec3(0.6f, 0.6f, 0.6f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 35.0f, 6.0f);

	m_pShaderManager->setIntValue("bUseLighting", false); // solid color, no lighting
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f); // white
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	m_basicMeshes->DrawSphereMesh();

	// Light 1 marker (blue fill light source)
	scaleXYZ = glm::vec3(0.6f, 0.6f, 0.6f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-28.0f, 8.0f, 20.0f);

	SetShaderColor(0.2f, 0.45f, 1.0f, 1.0f); // blue
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	m_basicMeshes->DrawSphereMesh();

	m_pShaderManager->setIntValue("bUseLighting", true); // turn lighting back on

	/*****************************************************************
	*                     PIANO BENCH SET                            *
	******************************************************************/

	// TEMP: Enable wireframe mode to show shape boundaries
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// Piano Bench - Seat Top
	
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(10.3f, 0.5f, 5.3f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 3.3f, 0.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// shinier piano material
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 80.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 64.0f); 
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.70f);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(1.0f, 1.0f);
	SetScratchUVScale(1.0f, 1.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);
	/****************************************************************/

	// TEMP: Enable wireframe mode to show shape boundaries
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// Piano Bench - Seat Base

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(10.0f, 1.5f, 5.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 2.7f, 0.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(1.0f, 0.3f);
	SetScratchUVScale(0.5f, 0.7f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);
	/****************************************************************/

	// TEMP: Enable wireframe mode to show shape boundaries
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// Piano Bench - Seat Leg - Front Left

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 6.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.5f, -1.05f, 2.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(0.3f, 0.3f);
	SetScratchUVScale(1.0f, 1.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawTaperedBoxMesh();
	SetUseScratch(false);
	/****************************************************************/

	// TEMP: Enable wireframe mode to show shape boundaries
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// Piano Bench - Seat Leg - Front Right

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 6.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.5f, -1.05f, 2.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(0.1f, 0.1f);
	SetScratchUVScale(1.0f, 1.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawTaperedBoxMesh();
	SetUseScratch(false);
	/****************************************************************/

	// TEMP: Enable wireframe mode to show shape boundaries
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// Piano Bench - Seat Leg - Back Left

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 6.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.5f, -1.05f, -2.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(0.1f, 0.1f);
	SetScratchUVScale(1.0f, 1.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawTaperedBoxMesh();
	SetUseScratch(false);
	/****************************************************************/

	// TEMP: Enable wireframe mode to show shape boundaries
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// Piano Bench - Seat Leg - Back Right

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 6.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.5f, -1.05f, -2.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(0.1f, 0.1f);
	SetScratchUVScale(1.0f, 1.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawTaperedBoxMesh();
	SetUseScratch(false);

	// reset shinier piano material
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 80.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 64.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.70f);
	/****************************************************************/

	/*****************************************************************
	*                        BACK WALL                               *
	******************************************************************/

	// TEMP: Enable wireframe mode to show shape boundaries
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// set the XYZ Scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 15.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 10.94f, -10.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set same floor material 
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.15f));
	m_pShaderManager->setFloatValue("material.shininess", 10.0f);

	// apply wall texture to mesh
	SetShaderTexture("wallPaint");
	SetTextureUVScale(2.5f, 1.5f);
	SetUseScratch(false);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawPlaneMesh();

	// restore normal wood material
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.5f));
	m_pShaderManager->setFloatValue("material.shininess", 24.0f);
	/*******************************************************************/

	/*****************************************************************
	*                      UPRIGHT PIANO SET                         *
	******************************************************************/

	// TEMP: Enable wireframe mode to show shape boundaries
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// Piano - Main Cabinet

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(30.0f, 17.5f, 5.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 1.2f, -7.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// shinier piano material
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 80.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 64.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.70f);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(1.8f, 0.8f);
	SetScratchUVScale(1.3f, 0.9f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);
	/********************************************************************/

	// Piano - Top Shelf Overhang

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(30.8f, 0.6f, 6.2f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 10.0f, -6.8f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(1.4f, 1.0f);	
	SetScratchUVScale(1.0f, 0.4f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);
	/*******************************************************************/

	// Piano - Keybed / Front Ledge

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(30.0f, 1.6f, 4.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh (slightly in front of cabinet)
	positionXYZ = glm::vec3(0.0f, 6.0f, -2.3f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(2.0f, 1.0f);
	SetScratchUVScale(1.0f, 0.4f);
	

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);
	/*********************************************************************/

	// Piano - Front Left Leg

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 10.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-14.5f, 1.0f, -1.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(0.25f, 0.6f);
	

	// draw the mesh with the transformation values
	m_basicMeshes->DrawTaperedBoxMesh();
	SetUseScratch(false);
	/***********************************************************************/

	// Piano - Front Right Leg

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 10.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(14.5f, 1.0f, -1.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(0.25f, 0.6f);
	

	// draw the mesh with the transformation values
	m_basicMeshes->DrawTaperedBoxMesh();
	SetUseScratch(false);
	/***********************************************************************/

	// Piano - Pedal Box

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 1.2f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, -2.8f, -3.8f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(0.8f, 0.4f);
	SetScratchUVScale(1.0f, 0.4f);
	

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);

	// reset shinier piano material
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 80.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 64.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.70f);
	/***************************************************************************/

	// Piano - Three Pedals

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.25f, 0.25f, 1.2f);

	// set the XYZ rotation for the mesh 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// base position for pedals
	glm::vec3 pedalBase = glm::vec3(0.0f, -3.0f, -3.4f);

	// Left pedal
	positionXYZ = pedalBase + glm::vec3(-1.2f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set material for pedals
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.5f));
	m_pShaderManager->setFloatValue("material.shininess", 150.0f);

	// apply texture to mesh
	SetShaderTexture("gold");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Middle pedal
	positionXYZ = pedalBase + glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("gold");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Right pedal
	positionXYZ = pedalBase + glm::vec3(1.2f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("gold");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();

	// reset pedal metarial
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.15f));
	m_pShaderManager->setFloatValue("material.shininess", 10.0f);
	/*********************************************************************/

	// Piano - Music Stand

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(14.0f, 3.8f, 0.4f);

	// set the XYZ rotation for the mesh (slightly tilted back)
	XrotationDegrees = -12.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 10.0f, -3.4f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ, 
		XrotationDegrees, 
		YrotationDegrees, 
		ZrotationDegrees, 
		positionXYZ);

	// shinier piano material
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 80.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 64.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.70f);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(1.2f, 0.6f);
	SetScratchUVScale(1.0f, 0.4f);
	

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);
	/****************************************************************/

	// Piano - Fallboard (Key Cover) - Closed

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(29.0f, 4.0f, 0.6f);

	// set the XYZ rotation for the mesh (vertical, covering keys)
	XrotationDegrees = -80.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh (just in front of the keybed)
	positionXYZ = glm::vec3(0.0f, 7.5f, -2.20f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(1.6f, 0.6f);
	SetScratchUVScale(1.1f, 0.9f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);
	/*************************************************************************/

	// Piano - Fallboard Rest

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(29.0f, 2.6f, 0.4f);

	// set the XYZ rotation for the mesh (vertical, covering keys)
	XrotationDegrees = -90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh (just in front of the keybed)
	positionXYZ = glm::vec3(0.0f, 8.06f, -3.5f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(1.6f, 0.6f);
	SetScratchUVScale(1.1f, 0.9f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);
	/*************************************************************************/

	// Piano - side barrier left

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 2.0f, 0.4f);

	// set the XYZ rotation for the mesh (vertical, covering keys)
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh (just in front of the keybed)
	positionXYZ = glm::vec3(14.74f, 7.6f, -2.34f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(1.6f, 0.6f);
	SetScratchUVScale(1.1f, 0.9f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);
	/*************************************************************************/

	// Piano - side barrier left

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 2.0f, 0.4f);

	// set the XYZ rotation for the mesh (vertical, covering keys)
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh (just in front of the keybed)
	positionXYZ = glm::vec3(-14.74f, 7.6f, -2.34f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture to mesh
	SetShaderTexture("pianoWood");
	SetScratchTextures("scratch1", "scratch2", "scratch3");
	SetUseScratch(true);
	SetTextureUVScale(1.6f, 0.6f);
	SetScratchUVScale(1.1f, 0.9f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	SetUseScratch(false);

	// reset shinier piano material
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 80.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 64.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.70f);
	/*************************************************************************/

	/****************************************************************************
	*                           TABLE LAMP SET                                  *
	*****************************************************************************/

	// Lamp - base

	glm::vec3 lampBasePos = glm::vec3(9.5f, 10.3f, -6.6f);

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.20f, 0.4f, 1.20f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = lampBasePos;

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);	

	// apply texture / material to mesh
	SetShaderTexture("blackMetal");
	SetTextureUVScale(3.5f, 0.20f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 96.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawCylinderMesh();
	/*****************************************************************/

	// Lamp - base ring

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 0.06f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = lampBasePos + glm::vec3(0.0f, 0.01f, 0.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture / material to mesh
	SetShaderTexture("blackMetal");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.8f));
	m_pShaderManager->setFloatValue("material.shininess", 64.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawCylinderMesh();
	/*****************************************************************/

	// Lamp - collar

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.20f, 0.26f, 0.20f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = lampBasePos + glm::vec3(0.0f, 0.30f, 0.0f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture / material to mesh
	SetShaderTexture("blackMetal");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 96.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawCylinderMesh();
	/*****************************************************************/

	// Lamp - gooseneck group

	// common material for the neck
	SetShaderTexture("stainless");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.35f));
	m_pShaderManager->setFloatValue("material.shininess", 64.0f);

	// Segment 1
	scaleXYZ = glm::vec3(0.10f, 0.90f, 0.10f);
	XrotationDegrees = 0.0f;  YrotationDegrees = 0.0f;   ZrotationDegrees = 0.0f;
	positionXYZ = lampBasePos + glm::vec3(0.00f, 0.50f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Segment 2
	scaleXYZ = glm::vec3(0.10f, 0.60f, 0.10f);
	XrotationDegrees = 12.0f;  YrotationDegrees = 0.0f;   ZrotationDegrees = 4.0f;
	positionXYZ = lampBasePos + glm::vec3(0.0f, 1.30f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Segment 3
	scaleXYZ = glm::vec3(0.10f, 0.60f, 0.10f);
	XrotationDegrees = 14.0f;  YrotationDegrees = 0.0f;   ZrotationDegrees = 4.5f;
	positionXYZ = lampBasePos + glm::vec3(-0.042f, 1.85f, 0.10f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Segment 4
	scaleXYZ = glm::vec3(0.10f, 0.60f, 0.10f);
	XrotationDegrees = 18.0f;  YrotationDegrees = 0.0f;   ZrotationDegrees = 5.0f;
	positionXYZ = lampBasePos + glm::vec3(-0.080f, 2.4f, 0.24f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Segment 5 (near the head)
	scaleXYZ = glm::vec3(0.10f, 0.80f, 0.10f);
	XrotationDegrees = 20.0f;  YrotationDegrees = 0.0f;   ZrotationDegrees = 5.0f;
	positionXYZ = lampBasePos + glm::vec3(-0.14f, 2.9f, 0.40f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();
	/*****************************************************************/

	// Lamp - head mount

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.22f, 0.16f, 0.22f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 45.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 5.0f;

	// set the XYZ position for the mesh (tip of the neck)
	positionXYZ = lampBasePos + glm::vec3(-0.18f, 3.55f, 0.58f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture / material to mesh
	SetShaderTexture("blackMetal");
	SetTextureUVScale(3.0f, 3.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.8f));
	m_pShaderManager->setFloatValue("material.shininess", 96.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawCylinderMesh();
	/*****************************************************************/

	// Lamp - shade

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.95f, 1.95f, 0.95f);

	// set the XYZ rotation for the mesh  (aim toward keys)
	XrotationDegrees = -55.0f;
	YrotationDegrees = -12.0f;
	ZrotationDegrees = -15.0f;

	// set the XYZ position for the mesh  (in front of the joint)
	positionXYZ = lampBasePos + glm::vec3(-0.50f, 3.40f, 1.45f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture / material to mesh (exterior)
	SetShaderTexture("blackMetal");
	SetTextureUVScale(2.0f, 2.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.30f));
	m_pShaderManager->setFloatValue("material.shininess", 56.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawConeMesh();
	/*****************************************************************/

	// Lamp - shade rim

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.80f, 0.05f, 0.80f);

	// set the XYZ rotation for the mesh (match shade)
	XrotationDegrees = -55.0f;
	YrotationDegrees = -12.0f;
	ZrotationDegrees = -15.0f;

	// set the XYZ position for the mesh (a bit forward from shade center)
	positionXYZ = lampBasePos + glm::vec3(-0.50f, 3.38f, 1.48f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply texture / material to mesh
	SetShaderTexture("frostedGlass");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.8f));
	m_pShaderManager->setFloatValue("material.shininess", 96.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawCylinderMesh();
	/*****************************************************************/

	// Lamp - bulb and socket

	// socket
	scaleXYZ = glm::vec3(0.22f, 0.12f, 0.22f);
	XrotationDegrees = -55.0f;  YrotationDegrees = -12.0f;  ZrotationDegrees = 0.0f;
	positionXYZ = lampBasePos + glm::vec3(-0.45f, 3.30f, 1.14f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("brass");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);
	m_basicMeshes->DrawCylinderMesh();

	// tiny �bulb�
	scaleXYZ = glm::vec3(0.18f, 0.18f, 0.18f);
	XrotationDegrees = -55.0f;  YrotationDegrees = -12.0f;  ZrotationDegrees = 0.0f;
	positionXYZ = lampBasePos + glm::vec3(-0.45f, 3.30f, 1.20f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("brass");          // no true emission; just a bright specular metal
	SetUseScratch(false);
	m_basicMeshes->DrawSphereMesh();
	/*****************************************************************/

	/*****************************************************************
*                        WALL PICTURE (portrait, leaning)        *
******************************************************************/

	// Poster panel 

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.5f, 1.5f, 3.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 17.5f, -9.98f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// matte paper (low spec)
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.08f));
	m_pShaderManager->setFloatValue("material.shininess", 80.0f);

	// apply poster texture to mesh (flip V if needed)
	SetShaderTexture("pianoPoster");
	SetTextureUVScale(1.0f, 1.0f);   // use (1.0f, -1.0f) if upside-down
	SetUseScratch(false);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawPlaneMesh();
	/******************************************************************/

	/*** Frame � top rail ***/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.2f, 0.4f, 0.2f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 20.70f, -9.95f);

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// glossy gold/brass frame
	SetShaderTexture("pianoWood");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.7f));
	m_pShaderManager->setFloatValue("material.shininess", 64.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	/******************************************************************/

	/*** Frame � bottom rail (thicker) ***/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.2f, 0.4f, 0.2f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 14.30f, -9.95f);

	// set the XYZ transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// glossy gold/brass frame
	SetShaderTexture("pianoWood");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.7f));
	m_pShaderManager->setFloatValue("material.shininess", 64.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	/******************************************************************/

	/*** Frame � left rail ***/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.3f, 6.8f, 0.2f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.65f, 17.5f, -9.95f);

	// set the XYZ transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// glossy gold/brass frame
	SetShaderTexture("pianoWood");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.7f));
	m_pShaderManager->setFloatValue("material.shininess", 64.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	/******************************************************************/

	/*** Frame � right rail ***/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.3f, 6.8f, 0.2f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-2.38f, 17.5f, -9.95f);

	// set the XYZ transformations into memory to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// glossy gold/brass frame
	SetShaderTexture("pianoWood");
	SetTextureUVScale(1.0f, 1.0f);
	SetUseScratch(false);
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.7f));
	m_pShaderManager->setFloatValue("material.shininess", 64.0f);

	// draw the mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();
	/******************************************************************/

	// restore a typical material for following meshes
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.5f));
	m_pShaderManager->setFloatValue("material.shininess", 24.0f);
}
